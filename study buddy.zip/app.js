
// ==================================
// 1. PLAYER DATA
// ==================================

let player = {
    name: "Farida",
    xp: 0,
    coins: 0,
    level: 1
};

let completedLessons = [];
let battleRewardClaimed = false;

let studyStreak = 0;
let lastStudyDate = null;


// ==================================
// 2. ECONOMICS QUESTIONS
// ==================================

const questions = [
    {
        question: "What is demand?",
        options: [
            "The quantity producers want to sell",
            "The quantity consumers are willing and able to buy",
            "The total amount of money in an economy",
            "The cost of producing a product"
        ],
        answer: 1,
        explanation: "Demand is the quantity consumers are willing and able to buy at different prices over a given period."
    },

    {
        question: "What normally happens to quantity demanded when price rises?",
        options: [
            "It increases",
            "It stays the same",
            "It decreases",
            "It becomes zero"
        ],
        answer: 2,
        explanation: "According to the law of demand, a higher price generally leads to a lower quantity demanded, other things remaining equal."
    },

    {
        question: "What is supply?",
        options: [
            "The quantity producers are willing and able to sell",
            "The quantity consumers want to purchase",
            "The amount of tax paid by consumers",
            "The total demand in a market"
        ],
        answer: 0,
        explanation: "Supply refers to the quantity producers are willing and able to sell at different prices over a given period."
    },

    {
        question: "When does market equilibrium occur?",
        options: [
            "When demand is zero",
            "When prices are highest",
            "When supply is greater than demand",
            "When quantity demanded equals quantity supplied"
        ],
        answer: 3,
        explanation: "Market equilibrium occurs where quantity demanded equals quantity supplied."
    },

    {
        question: "What generally happens when demand increases, assuming supply stays constant?",
        options: [
            "Price and quantity fall",
            "Price and quantity rise",
            "Price falls and quantity rises",
            "Nothing changes"
        ],
        answer: 1,
        explanation: "An increase in demand shifts the demand curve to the right, generally increasing equilibrium price and quantity."
    }
];


// ==================================
// 3. GAME STATE
// ==================================

let currentQuestion = 0;
let score = 0;

// ==================================
// STUDY STREAK SYSTEM
// ==================================

function recordStudyActivity() {
    
    let today = new Date().toLocaleDateString("en-CA");
    
    if (lastStudyDate === today) {
        return;
    }
    
    if (lastStudyDate) {
        
        let previousDate = new Date(lastStudyDate + "T00:00:00");
        let currentDate = new Date(today + "T00:00:00");
        
        let difference = Math.round(
            (currentDate - previousDate) / (1000 * 60 * 60 * 24)
        );
        
        if (difference === 1) {
            studyStreak++;
        } else {
            studyStreak = 1;
        }
        
    } else {
        studyStreak = 1;
    }
    
    lastStudyDate = today;
    
    localStorage.setItem("studyBuddyStreak", JSON.stringify({
        streak: studyStreak,
        lastDate: lastStudyDate
    }));
    
    updatePlayerDisplay();
}

// ==================================
// 4. SAVE AND LOAD PLAYER
// ==================================

function loadPlayer() {

    let savedPlayer = localStorage.getItem("studyBuddyPlayer");

    if (savedPlayer) {
        player = JSON.parse(savedPlayer);
    }

    let savedLessons = localStorage.getItem("studyBuddyLessons");

    if (savedLessons) {
        completedLessons = JSON.parse(savedLessons);
    }

    battleRewardClaimed =
        localStorage.getItem("studyBuddyBattleReward") === "true";
        
        let savedStreak = localStorage.getItem("studyBuddyStreak");

if (savedStreak) {
    
    let streakData = JSON.parse(savedStreak);
    
    studyStreak = streakData.streak;
    lastStudyDate = streakData.lastDate;
    
}

let savedAchievements = JSON.parse(
    localStorage.getItem("studyBuddyAchievements") || "[]"
);

savedAchievements.forEach(function(id) {
    unlockAchievement(id);
});

    updatePlayerDisplay();
    updateLessonProgress();
}


function savePlayer() {

    localStorage.setItem(
        "studyBuddyPlayer",
        JSON.stringify(player)
    );

    localStorage.setItem(
        "studyBuddyLessons",
        JSON.stringify(completedLessons)
    );
}


// ==================================
// 5. PLAYER STATISTICS
// ==================================



function updatePlayerDisplay() {

    // Update player statistics
    document.getElementById("player-xp").textContent = player.xp;

    document.getElementById("player-coins").textContent = player.coins;

    document.getElementById("player-level").textContent = player.level;

    // Update study streak
    document.getElementById("player-streak").textContent =
        studyStreak + (studyStreak === 1 ? " day" : " days");

    // Calculate XP progress
    let progress = (player.xp / 300) * 100;

    // Update progress bar
    document.getElementById("xp-bar-fill").style.width = progress + "%";

    // Update XP counter
    document.getElementById("xp-progress-text").textContent =
        player.xp + " / 300 XP";
}



function earnXP(amount) {

    player.xp += amount;

    while (player.xp >= 300) {

        player.xp -= 300;
        player.level++;

        alert("LEVEL UP! You reached level " + player.level + "! 🎉");
    }

    updatePlayerDisplay();
    savePlayer();
}


// ==================================
// 6. SCREEN NAVIGATION
// ==================================

function openEconomics() {

    document.querySelector(".welcome").classList.add("hidden");
    document.querySelector(".stats").classList.add("hidden");
    document.querySelector(".subjects").classList.add("hidden");
    document.querySelector(".daily-quest").classList.add("hidden");

    document.getElementById("economics-screen").classList.remove("hidden");
}


function openHome() {

    document.getElementById("economics-screen").classList.add("hidden");
    document.getElementById("battle-screen").classList.add("hidden");

    document.querySelector(".welcome").classList.remove("hidden");
    document.querySelector(".stats").classList.remove("hidden");
    document.querySelector(".subjects").classList.remove("hidden");
    document.querySelector(".daily-quest").classList.remove("hidden");
}


document.getElementById("back-home").addEventListener("click", openHome);

document.querySelector(".economics").addEventListener("click", openEconomics);

document.getElementById("start-quest").addEventListener("click", openEconomics);

// Other subjects are coming soon
document.querySelectorAll(".subject-card:not(.economics)").forEach(function(button) {
    
    button.addEventListener("click", function() {
        
        let subject = button.querySelector("h3").textContent;
        
        alert(subject + " adventures are coming soon! 🚀");
        
    });
    
});


// ==================================
// 7. LESSON COMPLETION
// ==================================

function updateLessonProgress() {

    document.getElementById("lesson-progress-text").textContent =
        completedLessons.length + " / 4 completed";
}


document.querySelectorAll(".complete-lesson").forEach(function(button) {

    let lessonNumber = Number(button.dataset.lesson);

    if (completedLessons.includes(lessonNumber)) {

        button.textContent = "Completed ✓";
        button.disabled = true;
    }

    button.addEventListener("click", function() {

        if (completedLessons.includes(lessonNumber)) {
            return;
        }

        completedLessons.push(lessonNumber);
        
        unlockAchievement("achievement-first");
        
        recordStudyActivity();

        button.textContent = "Completed ✓";
        button.disabled = true;

        player.coins += 5;

        earnXP(25);

        updateLessonProgress();
        savePlayer();

        alert("Lesson completed! +25 XP and +5 coins! ⭐");
    });
});


// ==================================
// 8. START BATTLE
// ==================================

function startBattle() {

    currentQuestion = 0;
    score = 0;

    document.getElementById("economics-screen").classList.add("hidden");

    document.getElementById("battle-screen").classList.remove("hidden");

    document.querySelector(".question-card").classList.remove("hidden");

    document.getElementById("battle-results").classList.add("hidden");

    showQuestion();
}


document.getElementById("start-battle").addEventListener("click", startBattle);


// ==================================
// 9. DISPLAY QUESTION
// ==================================

function showQuestion() {

    let question = questions[currentQuestion];

    document.getElementById("question-counter").textContent =
        "Question " + (currentQuestion + 1) + " / " + questions.length;

    document.getElementById("battle-score").textContent =
        "Score: " + score;

    document.getElementById("question-text").textContent =
        question.question;

    document.getElementById("answer-feedback").textContent = "";

    document.getElementById("next-question").classList.add("hidden");

    let optionsContainer = document.getElementById("answer-options");

    optionsContainer.innerHTML = "";

    question.options.forEach(function(option, index) {

        let button = document.createElement("button");

        button.className = "answer-option";
        button.textContent = option;

        button.addEventListener("click", function() {
            checkAnswer(index);
        });

        optionsContainer.appendChild(button);
    });
}


// ==================================
// 10. CHECK ANSWER
// ==================================

function checkAnswer(selectedAnswer) {

    let question = questions[currentQuestion];

    let buttons = document.querySelectorAll(".answer-option");

    buttons.forEach(function(button) {
        button.disabled = true;
    });

    let feedback = document.getElementById("answer-feedback");

    if (selectedAnswer === question.answer) {

        score++;

        buttons[selectedAnswer].classList.add("correct");

        feedback.textContent = "Correct! ⭐ " + question.explanation;

    } else {

        buttons[selectedAnswer].classList.add("incorrect");

        buttons[question.answer].classList.add("correct");

        feedback.textContent = "Not quite! " + question.explanation;
    }

    document.getElementById("battle-score").textContent =
        "Score: " + score;

    document.getElementById("next-question").classList.remove("hidden");
}


// ==================================
// 11. NEXT QUESTION
// ==================================

document.getElementById("next-question").addEventListener("click", function() {

    currentQuestion++;

    if (currentQuestion < questions.length) {

        showQuestion();

    } else {

        finishBattle();
    }
});


// ==================================
// 12. FINISH BATTLE
// ==================================

function finishBattle() {
    
    recordStudyActivity();
    
    unlockAchievement("achievement-battle");

if (score === 5) {
    unlockAchievement("achievement-perfect");
}

    document.querySelector(".question-card").classList.add("hidden");

    document.getElementById("battle-results").classList.remove("hidden");

    document.getElementById("result-message").textContent =
        "You answered " + score + " out of 5 questions correctly!";

    if (!battleRewardClaimed) {

        let xpReward = score * 20;
        let coinReward = score * 5;

        player.coins += coinReward;

        earnXP(xpReward);

        battleRewardClaimed = true;

        localStorage.setItem("studyBuddyBattleReward", "true");

        document.getElementById("result-reward").textContent =
            "Rewards: +" + xpReward + " XP and +" + coinReward + " coins!";

    } else {

        document.getElementById("result-reward").textContent =
            "You've already claimed your battle rewards. Keep practising!";
    }

    if (score === 5) {

        document.getElementById("result-message").textContent +=
            " Perfect score! Demand Dragon has been defeated! 🐉";

    } else if (score >= 3) {

        document.getElementById("result-message").textContent +=
            " Good work, Explorer!";

    } else {

        document.getElementById("result-message").textContent +=
            " Review your lessons and try again!";
    }
}


// ==================================
// 13. RETURN BUTTONS
// ==================================

document.getElementById("back-to-lessons").addEventListener("click", function() {

    document.getElementById("battle-screen").classList.add("hidden");

    document.getElementById("economics-screen").classList.remove("hidden");
});


document.getElementById("return-home").addEventListener("click", openHome);

// Click the Study Buddy logo to return Home
document.getElementById("home-logo").addEventListener("click", openHome);

// ==================================
// SIDEBAR NAVIGATION
// ==================================

// Home
document.getElementById("nav-home").addEventListener("click", openHome);

// Subjects
document.getElementById("nav-subjects").addEventListener("click", openHome);

// Quests
document.getElementById("nav-quests").addEventListener("click", openEconomics);

// Battle
document.getElementById("nav-battle").addEventListener("click", function() {
    openEconomics();
    startBattle();
});

// Profile
document.getElementById("nav-profile").addEventListener("click", function() {
    
    alert(
        "PLAYER PROFILE\n\n" +
        "Name: " + player.name + "\n" +
        "Level: " + player.level + "\n" +
        "XP: " + player.xp + "\n" +
        "Coins: " + player.coins + "\n" +
        "Study Streak: " + studyStreak + " days"
    );
    
});


// ==================================
// ACHIEVEMENT SYSTEM
// ==================================

function unlockAchievement(id) {
    let achievement = document.getElementById(id);
    
    if (achievement) {
        achievement.classList.remove("locked");
        achievement.classList.add("unlocked");
        
        let savedAchievements = JSON.parse(
            localStorage.getItem("studyBuddyAchievements") || "[]"
        );
        
        if (!savedAchievements.includes(id)) {
            savedAchievements.push(id);
        }
        
        localStorage.setItem(
            "studyBuddyAchievements",
            JSON.stringify(savedAchievements)
        );
    }
}

// ==================================
// 14. START APPLICATION
// ==================================

loadPlayer();
